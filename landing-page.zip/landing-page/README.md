# Landing Page Project

css
java
html
change static to dynamic