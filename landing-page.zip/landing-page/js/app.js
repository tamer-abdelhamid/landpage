//global section var
const sections=document.querySelectorAll('section');
//global navigation var
const navList=document.getElementById('navbar__list');
const taUl=document.querySelector('ul');
const tanavList=document.querySelectorAll('nav ul li');
//bld the Navigation
function tanavigationcreator(){
  for(section of sections){
    sectionName=section.getAttribute('data-nav');
    sectionLink=section.getAttribute('id');
//cretae Li for sections
listItem=document.createElement('li');
//add txt to li
listItem.innerHTML=`<a class="menu__link" data-link="${sectionLink}">${sectionName}</a>` ;
//adding listitems to Navigation
navList.appendChild(listItem);

  }
}

//any section in viewport
const secLoc=(section)=>{
  return Math.floor(section.getBoundingClientRect().top);
};
//remove active class from sec
const removeActvClass=(section)=>{
section.classList.remove('your-active-class');
};
// add actv class to actv section
const addActvClass=(condtional,section)=>{
  if(condtional){
    section.classList.add('your-active-class');
  }
}
//apply actv section function
const secViewPort =()=>{
  sections.forEach(section=>{
    const itemLoc=secLoc(section);
    inViewPort=()=>itemLoc<150 && itemLoc >=150;
    removeActvClass(section);
    addActvClass(inViewPort(),section);
  });
}


//run function bld nav
tanavigationcreator();

//adding active class to eventlistener
window.addEventListener('scroll', secViewPort);

//scroll into view
const allLists=document.querySelectorAll('.navbar__menu .menu__link');
allLists.forEach((link)=>){
  link.addEventListener('click',()=>{
    let elem=document.getElementById(link.getAttribute("data-link"));
    elem.scrollIntoView({behavior:'smooth'});
  });
});
